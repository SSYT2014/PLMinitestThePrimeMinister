#! /usr/bin/env python
# -*- coding: utf-8 -*-
__author__ = "Tokuume Shinya<g1244785@cc.kyoto-su.ac.jp>"
__status__ = "production"
__date__ = "22 December 2014"


"""パッケージに必要な「__initi__.py」ファイル。"""

# print "*** primeministers ***"
